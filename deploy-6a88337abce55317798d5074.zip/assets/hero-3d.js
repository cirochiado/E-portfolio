/* ===== Hero 3D — poliedro wireframe con nucleo luminoso e particelle ===== */
(function () {
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var canvas = document.getElementById("hero-3d-canvas");
  if (!canvas || typeof THREE === "undefined") return;

  var stage = canvas.parentElement;

  var scene = new THREE.Scene();
  var camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
  camera.position.set(0, 0, 7);

  var renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, alpha: true });
  } catch (e) {
    return;
  }
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));

  function resize() {
    var w = stage.clientWidth;
    var h = stage.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  // Nucleo pieno, quasi trasparente, effetto "vetro luminoso"
  var coreGeo = new THREE.IcosahedronGeometry(1.05, 1);
  var coreMat = new THREE.MeshBasicMaterial({ color: 0x60a5fa, transparent: true, opacity: 0.10 });
  var core = new THREE.Mesh(coreGeo, coreMat);
  scene.add(core);

  // Guscio esterno wireframe, blu
  var shellGeo = new THREE.IcosahedronGeometry(1.95, 1);
  var shellEdges = new THREE.EdgesGeometry(shellGeo);
  var shellMat = new THREE.LineBasicMaterial({ color: 0x60a5fa, transparent: true, opacity: 0.55 });
  var shell = new THREE.LineSegments(shellEdges, shellMat);
  scene.add(shell);

  // Guscio interno wireframe, ciano, ruota in senso opposto per dare profondità
  var shell2Geo = new THREE.IcosahedronGeometry(1.48, 1);
  var shell2Edges = new THREE.EdgesGeometry(shell2Geo);
  var shell2Mat = new THREE.LineBasicMaterial({ color: 0x22d3ee, transparent: true, opacity: 0.38 });
  var shell2 = new THREE.LineSegments(shell2Edges, shell2Mat);
  scene.add(shell2);

  // Particelle orbitanti, viola, in una nuvola sferica intorno al poliedro
  var particleCount = 70;
  var positions = new Float32Array(particleCount * 3);
  for (var i = 0; i < particleCount; i++) {
    var r = 2.6 + Math.random() * 0.7;
    var theta = Math.random() * Math.PI * 2;
    var phi = Math.acos(Math.random() * 2 - 1);
    positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = r * Math.cos(phi);
  }
  var particleGeo = new THREE.BufferGeometry();
  particleGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
  var particleMat = new THREE.PointsMaterial({ color: 0xa78bfa, size: 0.045, transparent: true, opacity: 0.85 });
  var particles = new THREE.Points(particleGeo, particleMat);
  scene.add(particles);

  var pointerFine = window.matchMedia && window.matchMedia("(pointer:fine)").matches;
  var targetRotX = 0;
  var targetRotY = 0;

  if (pointerFine) {
    stage.addEventListener("pointermove", function (e) {
      var rect = stage.getBoundingClientRect();
      var x = (e.clientX - rect.left) / rect.width - 0.5;
      var y = (e.clientY - rect.top) / rect.height - 0.5;
      targetRotY = x * 0.6;
      targetRotX = y * 0.4;
    });
  }

  window.addEventListener("resize", resize);
  resize();

  if (reduceMotion) {
    // Un solo frame statico, nessuna animazione continua
    renderer.render(scene, camera);
    return;
  }

  var clock = new THREE.Clock();
  var rafId;

  function animate() {
    rafId = requestAnimationFrame(animate);
    var t = clock.getElapsedTime();
    shell.rotation.y = t * 0.12 + targetRotY;
    shell.rotation.x = t * 0.05 + targetRotX;
    shell2.rotation.y = -t * 0.09 - targetRotY * 0.6;
    shell2.rotation.x = t * 0.07 + targetRotX * 0.6;
    core.rotation.y = t * 0.08;
    particles.rotation.y = t * 0.03;
    renderer.render(scene, camera);
  }

  document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
      cancelAnimationFrame(rafId);
    } else {
      animate();
    }
  });

  animate();
})();
