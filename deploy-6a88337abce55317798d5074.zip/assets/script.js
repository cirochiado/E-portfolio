const toggle = document.querySelector('.mobile-toggle');
const menu = document.querySelector('.menu');
if (toggle && menu) {
  toggle.addEventListener('click', () => menu.classList.toggle('open'));
}









// VALIDAZIONE DEFINITIVA FORM CONTATTI
document.addEventListener("DOMContentLoaded", function () {
  var form = document.querySelector('form[name="contatti"]');
  if (!form) return;

  var formError = document.getElementById("form-error");
  var captchaError = document.getElementById("captcha-error");

  function showError(element, message) {
    if (!element) return;
    element.textContent = message;
    element.style.display = "block";
    element.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  function hideError(element) {
    if (!element) return;
    element.style.display = "none";
  }

  function isRealVisibleField(field) {
    if (!field) return false;
    if (field.type === "hidden" || field.type === "submit" || field.type === "button") return false;
    if (field.name === "bot-field") return false;
    if (field.closest('[style*="display:none"]')) return false;
    return true;
  }

  function validateForm(event) {
    var fields = Array.prototype.slice.call(form.querySelectorAll("input, textarea, select"))
      .filter(isRealVisibleField)
      .filter(function (field) {
        return field.hasAttribute("required");
      });

    var firstInvalid = null;
    var invalid = false;

    fields.forEach(function (field) {
      var value = (field.value || "").trim();
      var fieldInvalid = false;

      if (field.type === "checkbox" && field.hasAttribute("required") && !field.checked) fieldInvalid = true;
      else if (value.length === 0) fieldInvalid = true;
      if (field.tagName.toLowerCase() === "textarea" && value.length < 10) fieldInvalid = true;
      if (field.type === "email" && value.length > 0 && !field.checkValidity()) fieldInvalid = true;

      if (fieldInvalid) {
        invalid = true;
        field.classList.add("is-invalid");
        field.setAttribute("aria-invalid", "true");
        if (!firstInvalid) firstInvalid = field;
      } else {
        field.classList.remove("is-invalid");
        field.removeAttribute("aria-invalid");
      }
    });

    if (invalid) {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();

      showError(formError, "Compila tutti i campi richiesti e conferma di aver letto la Privacy Policy.");
      if (firstInvalid) firstInvalid.focus();
      return false;
    }

    hideError(formError);

    var captchaResponse = document.querySelector('[name="g-recaptcha-response"]');
    if (captchaResponse && captchaResponse.value.trim() === "") {
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();

      showError(captchaError, "Completa il captcha prima di inviare la richiesta.");
      return false;
    }

    hideError(captchaError);
    return true;
  }

  form.addEventListener("submit", validateForm, true);

  form.addEventListener("input", function (event) {
    if (event.target && event.target.classList) {
      event.target.classList.remove("is-invalid");
      event.target.removeAttribute("aria-invalid");
    }
  });

  form.addEventListener("change", function (event) {
    if (event.target && event.target.classList) {
      event.target.classList.remove("is-invalid");
      event.target.removeAttribute("aria-invalid");
    }
  });
});


// Premium reveal animations
document.addEventListener("DOMContentLoaded", function () {
  var revealItems = document.querySelectorAll(".reveal");
  if (!revealItems.length) return;
  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14 });
  revealItems.forEach(function (item) { observer.observe(item); });
});


// Ultra premium interactions
document.addEventListener("DOMContentLoaded", function () {
  var progress = document.querySelector(".scroll-progress");
  function updateProgress(){
    if(!progress) return;
    var scrollTop = window.scrollY || document.documentElement.scrollTop;
    var docHeight = document.documentElement.scrollHeight - window.innerHeight;
    var pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    progress.style.width = pct + "%";
  }
  window.addEventListener("scroll", updateProgress, { passive:true });
  updateProgress();

  var glow = document.querySelector(".cursor-glow");
  if (glow && window.matchMedia("(pointer:fine)").matches) {
    document.addEventListener("mousemove", function(e){
      glow.style.left = e.clientX + "px";
      glow.style.top = e.clientY + "px";
    });
  } else if (glow) {
    glow.style.display = "none";
  }

  var tiltCards = document.querySelectorAll(".tilt-card:not(.browser-main)");
  tiltCards.forEach(function(card){
    card.addEventListener("mousemove", function(e){
      var r = card.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - .5;
      var y = (e.clientY - r.top) / r.height - .5;
      card.style.transform = "perspective(1000px) rotateY(" + (x * 5) + "deg) rotateX(" + (-y * 5) + "deg) translateY(-4px)";
    });
    card.addEventListener("mouseleave", function(){
      card.style.transform = "";
    });
  });
});


// Smooth anchor scroll for method page
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll('.method-progress-map a[href^="#"]').forEach(function(anchor){
    anchor.addEventListener("click", function(e){
      var target = document.querySelector(this.getAttribute("href"));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  });
});


/* ===== Ciro premium upgrade interactions ===== */
(function(){
  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce) return;
  document.querySelectorAll('[data-ciro-tilt]').forEach((el)=>{
    el.addEventListener('pointermove',(event)=>{
      const rect=el.getBoundingClientRect();
      const x=(event.clientX-rect.left)/rect.width-.5;
      const y=(event.clientY-rect.top)/rect.height-.5;
      el.style.setProperty('--tiltX', Math.max(-5,Math.min(5,-y*7)).toFixed(2)+'deg');
      el.style.setProperty('--tiltY', Math.max(-6,Math.min(6,x*8)).toFixed(2)+'deg');
    },{passive:true});
    el.addEventListener('pointerleave',()=>{
      el.style.setProperty('--tiltX','0deg');
      el.style.setProperty('--tiltY','0deg');
    });
  });
})();


// Cookie notice informativa
(function(){
  document.addEventListener("DOMContentLoaded", function(){
    var notice = document.getElementById("cookieNotice");
    var accept = document.getElementById("cookieAccept");
    if(!notice || !accept) return;
    try {
      if(localStorage.getItem("ccweb_cookie_notice_ok") === "1") {
        notice.style.display = "none";
        return;
      }
    } catch(e) {}
    notice.classList.add("is-visible");
    accept.addEventListener("click", function(){
      notice.classList.remove("is-visible");
      notice.style.display = "none";
      try { localStorage.setItem("ccweb_cookie_notice_ok", "1"); } catch(e) {}
    });
  });
})();
